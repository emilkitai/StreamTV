package com.streamtv.app

import android.net.Uri
import android.os.Bundle
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {
    private var player: ExoPlayer? = null
    private lateinit var root: LinearLayout
    private lateinit var playlistInput: EditText
    private lateinit var list: LinearLayout
    private lateinit var playerView: PlayerView
    private val channels = mutableListOf<Pair<String, String>>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 18, 18, 18) }
        root.setBackgroundColor(0xFF101820.toInt())
        val title = TextView(this).apply { text = "СТАРИЯ ЧАРК · IPTV"; textSize = 24f; setTextColor(0xFFFFFFFF.toInt()) }
        root.addView(title)
        playlistInput = EditText(this).apply {
            hint = "M3U URL или Xtream playlist URL"
            setHintTextColor(0xFFBBBBBB.toInt()); setTextColor(0xFFFFFFFF.toInt())
            setSingleLine(true)
        }
        root.addView(playlistInput, LinearLayout.LayoutParams(-1, -2))
        val load = Button(this).apply { text = "Зареди списък (M3U)"; setOnClickListener { loadPlaylist(playlistInput.text.toString().trim()) } }
        root.addView(load)
        playerView = PlayerView(this).apply { useController = true }
        root.addView(playerView, LinearLayout.LayoutParams(-1, 230))
        val channelTitle = TextView(this).apply { text = "Канали"; textSize = 18f; setTextColor(0xFFFFFFFF.toInt()); setPadding(0, 12, 0, 6) }
        root.addView(channelTitle)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = android.widget.ScrollView(this).apply { addView(list) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun loadPlaylist(url: String) {
        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            Toast.makeText(this, "Въведи валиден http/https M3U адрес", Toast.LENGTH_LONG).show(); return
        }
        Toast.makeText(this, "Зареждам списъка…", Toast.LENGTH_SHORT).show()
        thread {
            try {
                val conn = (URL(url).openConnection() as HttpURLConnection).apply { connectTimeout = 15000; readTimeout = 20000; setRequestProperty("User-Agent", "StreamTV/0.1") }
                val body = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                conn.disconnect()
                val parsed = mutableListOf<Pair<String, String>>()
                var name = "Канал"
                body.lineSequence().forEach { raw ->
                    val line = raw.trim()
                    if (line.startsWith("#EXTINF", true)) name = line.substringAfter(",", "Канал").trim().ifBlank { "Канал" }
                    else if (line.startsWith("http://") || line.startsWith("https://")) { parsed.add(name to line); name = "Канал ${parsed.size + 1}" }
                }
                runOnUiThread {
                    channels.clear(); channels.addAll(parsed); list.removeAllViews()
                    channels.forEach { channel ->
                        val button = Button(this).apply { text = channel.first; setOnClickListener { play(channel.second) } }
                        list.addView(button, ViewGroup.LayoutParams(-1, -2))
                    }
                    Toast.makeText(this, "Намерени канали: ${channels.size}", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, "Неуспешно зареждане. Провери адреса и интернет връзката.", Toast.LENGTH_LONG).show() }
            }
        }
    }

    private fun play(url: String) {
        if (player == null) { player = ExoPlayer.Builder(this).build(); playerView.player = player }
        player?.setMediaItem(MediaItem.fromUri(Uri.parse(url)))
        player?.prepare(); player?.playWhenReady = true
    }

    override fun onDestroy() { player?.release(); player = null; super.onDestroy() }
}
