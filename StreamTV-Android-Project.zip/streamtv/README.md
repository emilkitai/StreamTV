# StreamTV / Стария чарк

Starter Android IPTV player project. Supports loading an M3U playlist URL and playing listed HTTP(S) streams with Android Media3 ExoPlayer. This is an early, untested starter build, not a production-ready TiviMate replacement. EPG, favorites, Xtream Codes login UI, robust playlist parsing, and TV remote navigation are not implemented yet.

## Build APK

GitHub Actions workflow `.github/workflows/build-apk.yml` builds a debug APK. After the project files are committed, open the repository's Actions tab, run `Build StreamTV APK`, and download the `StreamTV-debug-apk` artifact.
